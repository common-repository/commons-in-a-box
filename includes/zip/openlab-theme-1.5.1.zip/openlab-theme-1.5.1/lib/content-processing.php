<?php

// content processing functions
// body classes for specific pages - partly legacy from Genesis Connect
add_filter( 'body_class', 'openlab_conditional_body_classes' );

function openlab_conditional_body_classes( $classes ) {
	global $post, $wp_query;
	$classes[] = 'header-image';

	$query_vars = array();
	if ( isset( $wp_query->query_vars ) ) {
		$query_vars = $wp_query->query_vars;
	}

	if ( is_front_page() || is_404() ) {
		$classes[] = 'full-width-content';
	} elseif ( isset( $post->post_name ) && 'register' === $post->post_name ) {
		$classes[] = 'content-sidebar';
	}

	if ( bp_is_groups_directory() || bp_is_members_directory() ) {
		$classes[] = 'group-archive-page';
	}

	$is_about_page = cboxol_is_brand_page( 'about' );
	if ( ! $is_about_page && ! empty( $post->post_parent ) ) {
		$is_about_page = cboxol_is_brand_page( 'about', $post->post_parent );
	}

	$calendar_page_obj = get_page_by_path( 'about/calendar' );
	$is_calendar_page  = cboxol_is_brand_page( 'calendar' );
	if ( ! $is_calendar_page && ! empty( $post->post_parent ) ) {
		$is_calendar_page = cboxol_is_brand_page( 'calendar', $post->post_parent );
	}

	if ( ( bp_is_groups_directory() || bp_is_members_directory() ) ||
			openlab_is_search_results_page() ||
			( function_exists( 'bp_is_single_item' ) && bp_is_single_item() ) ||
			( function_exists( 'bp_is_user' ) && bp_is_user() ) ||
			( $is_about_page ) ||
			( $is_calendar_page ) ||
			( isset( $post->post_type ) && 'help' === $post->post_type ) ||
			( isset( $post->post_type ) && 'help_glossary' === $post->post_type ) ||
			( ! empty( $query_vars ) && isset( $query_vars['help_category'] ) ) ) {
		$classes[] = 'sidebar-mobile-dropdown';
	}

	return $classes;
}

// truncate links in profile fields - I'm using $field->data->value to just truncate the link name (it was giving odd results when trying to truncate $value)
function openlab_filter_profile_fields( $value ) {
	global $field;
	$truncate_link_candidates = array( 'Website', 'LinkedIn Profile Link', 'Facebook Profile Link', 'Google Scholar profile' );
	if ( in_array( $field->name, $truncate_link_candidates, true ) ) {
		$args           = array(
			'ending' => __( '&hellip;', 'buddypress' ),
			'exact'  => true,
			'html'   => false,
		);
		$truncated_link = bp_create_excerpt( $field->data->value, 40, $args );
		$full_link      = openlab_http_check( $field->data->value );
		$value          = '<a href="' . $full_link . '">' . openlab_http_check( $truncated_link ) . '</a>';
	}
	return $value;
}
add_filter( 'bp_get_the_profile_field_value', 'openlab_filter_profile_fields', 10, 2 );

function openlab_http_check( $link ) {
	$http_check = strpos( $link, 'http' );

	if ( false === $http_check ) {
		$link = 'http://' . $link;
	}

	return $link;
}
remove_filter( 'get_the_excerpt', 'wp_trim_excerpt' );
add_filter( 'get_the_excerpt', 'cuny_add_links_wp_trim_excerpt' );

function cuny_add_links_wp_trim_excerpt( $text ) {
	$raw_excerpt = $text;
	if ( '' === $text ) {
		$text = get_the_content( '' );

		$text = strip_shortcodes( $text );

		$text           = apply_filters( 'the_content', $text );
		$text           = str_replace( ']]>', ']]>', $text );
		$text           = strip_tags( $text, '<a>' );
		$excerpt_length = apply_filters( 'excerpt_length', 55 );

		$excerpt_more = apply_filters( 'excerpt_more', ' [...]' );
		$words        = preg_split( '/( <a.*?a> )|\n|\r|\t|\s/', $text, $excerpt_length + 1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE );
		if ( count( $words ) > $excerpt_length ) {
			array_pop( $words );
			$text = implode( ' ', $words );
			$text = $text . $excerpt_more;
		} else {
			$text = implode( ' ', $words );
		}
	}
	return apply_filters( 'new_wp_trim_excerpt', $text, $raw_excerpt );
}

function openlab_get_menu_count_mup( $count, $pull_right = ' pull-right' ) {

	if ( $count < 1 ) {
		return '';
	} else {
		return '<span class="mol-count count-' . $count . $pull_right . '">' . $count . '</span>';
	}
}

function openlab_not_empty( $content ) {
	if ( $content && ! ctype_space( $content ) && '' !== $content ) {
		return true;
	} else {
		return false;
	}
}

function openlab_sidebar_cleanup( $content ) {

	$content = preg_replace( '/<iframe.*?\/iframe>/i', '', $content );
	$content = strip_tags( $content, '<br><i><em><b><strong><a><img>' );

	return $content;
}

/*
 * This function lets us customize status messages.
 */
function openlab_process_status_messages( $message ) {

	// invite anyone page
	if ( bp_current_action() === 'invite-anyone' ) {
		if ( trim( $message ) === '<p>Group invites sent.</p>' ) {
			$message = '<p>Your invitation was sent!</p>';
		}
	}

	return $message;
}
add_filter( 'bp_core_render_message_content', 'openlab_process_status_messages', 10 );

function openlab_generate_school_name( $group_id ) {
	$schools_out = '';
	$school_out  = array();

	$schools     = groups_get_groupmeta( $group_id, 'wds_group_school' );
	$schools_ary = explode( ',', $schools );

	if ( ! empty( $schools_ary ) ) {

		foreach ( $schools_ary as $school ) {
			switch ( $school ) {
				case 'tech':
					$school_out[] = 'Technology & Design';
					break;
				case 'studies':
					$school_out[] = 'Professional Studies';
					break;
				case 'arts':
					$school_out[] = 'Arts & Sciences';
					break;
			}
		}

		$schools_out = implode( ', ', $school_out );
	}

	return $schools_out;
}

function openlab_generate_department_name( $group_id ) {
	$departments_out = '';

	$departments     = groups_get_groupmeta( $group_id, 'wds_departments' );
	$departments_ary = explode( ',', $departments );

	if ( ! empty( $departments_ary ) ) {
		$departments_out = implode( ', ', $departments_ary );
	}

	return $departments_out;
}
