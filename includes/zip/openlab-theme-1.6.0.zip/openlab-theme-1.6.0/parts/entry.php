<div <?php post_class( 'col-sm-18 col-xs-24' ); ?>>
	<div id="openlab-main-content"  class="content-wrapper">
		<div class="entry-title">
			<h1><span class="profile-name"><?php the_title(); ?></span></h1>
		</div>
		<div class="entry-content"><?php the_content(); ?></div>
	</div>
</div><!--hentry-->
