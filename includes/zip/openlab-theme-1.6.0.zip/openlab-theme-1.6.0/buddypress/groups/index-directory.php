<?php
$current_type = bp_get_current_group_directory_type();
$type_object  = cboxol_get_group_type( $current_type );

// Redirect to the home page if we're not on a valid group directory page.
if ( is_wp_error( $type_object ) ) {
	bp_core_redirect( bp_get_root_url() );
}

get_header();

$can_create = is_user_logged_in() && bp_user_can_create_groups();
if ( $can_create ) {
	if ( $type_object->get_is_course() ) {
		$can_create = cboxol_user_can_create_courses( bp_loggedin_user_id() );
	} elseif ( $type_object->get_is_portfolio() ) {
		$can_create = ! openlab_user_has_portfolio( bp_loggedin_user_id() );
	}
}

$create_text = $type_object->get_can_be_cloned() ? __( 'Create / Clone', 'commons-in-a-box' ) : __( 'Create New', 'commons-in-a-box' );
$create_link = add_query_arg(
	[
		'group_type' => $type_object->get_slug(),
		'new'        => 'true',
	],
	bp_groups_get_create_url( [ 'group-details' ] )
);
?>

<div id="content" class="hfeed row">
	<?php get_template_part( 'parts/sidebar/groups' ); ?>
	<div <?php post_class( 'col-sm-18 col-xs-24' ); ?> role="main">
		<div id="openlab-main-content" class="content-wrapper">
			<div class="entry-title">
				<h1><?php echo esc_html( $type_object->get_label( 'plural' ) ); ?></h1>

				<div class="directory-title-meta">
					<?php if ( $can_create ) : ?>
						<span aria-hidden="true" class="fa fa-plus-circle hidden-xs"></span>
						<a class="hidden-xs" href="<?php echo esc_attr( $create_link ); ?>"><?php echo esc_html( $create_text ); ?></a>
					<?php endif; ?>
					<button data-target="#sidebar" data-backgroundonly="true" class="mobile-toggle direct-toggle pull-right visible-xs" type="button"></h1><span class="sr-only"><?php esc_html_e( 'Search', 'commons-in-a-box' ); ?></span><span class="fa fa-binoculars"></span></button>
				</div>
			</div>

			<div class="entry-content">
				<?php bp_get_template_part( 'groups/groups-loop' ); ?>
			</div><!--entry-content-->
		</div><!--hentry-->
	</div>
</div><!--content-->

<?php
get_footer();
