## User Documentation

This is where your end-user documentation could/should go.

This file is located in

	themes/infinity/engine/documents

and is written using Markdown.

> You could also use Textile or just plain old HTML if you prefer.

Doc are automatically inherited from themes higher up the scheme stack (if they exist),
and can be overridden the same way as you would do with a theme template.

### How we did it!

To see how we organized the developer docs, which might give you some ideas
of how to handle your own documentation, look in one of our base theme packages.

	themes/infinity/dashboard/docs
