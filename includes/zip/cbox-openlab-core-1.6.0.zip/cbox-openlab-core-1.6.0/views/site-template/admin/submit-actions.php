<div id="preview-action">
	<a class="preview button" target="_blank" href="<?php echo esc_url( $url ); ?>"><?php esc_html_e( 'View Site Template', 'cboxol-site-template-picker' ); ?></a>
</div>
