module.exports = {
	computed: {
		strings() {
			return this.$store.state.strings
		}
	}
}
