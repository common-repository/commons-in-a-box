WordPressn theme for Commons In A Box OpenLab project

[![Build Status](https://travis-ci.org/cuny-academic-commons/cbox-openlab-core.svg?branch=1.2.x)](https://travis-ci.org/cuny-academic-commons/cbox-openlab-core)

Part of the Commons In A Box project https://github.com/cuny-academic-commons/commons-in-a-box.

New bug reports and feature requests should go to the main Commons In A Box repo: https://github.com/cuny-academic-commons/commons-in-a-box/issues
